# 🗳️ Fabric Alliance Governance

The Fabric Alliance is governed through a decentralized DAO framework.

## DAO Voting
- Proposals submitted via `proposals/`
- Votes require quorum and majority approval

## Committees
- Certification Committee
- Ethics and Standards Council

## Transparency
- All audits and proposals are public and on-chain