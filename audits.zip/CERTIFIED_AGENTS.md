# ✅ Fabric Alliance – Certified Agents Registry

This document lists all certified AI agents verified by the Fabric Alliance.